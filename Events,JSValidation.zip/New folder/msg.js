/*type 3*/
function msg(){
	alert("Hello World");
} 